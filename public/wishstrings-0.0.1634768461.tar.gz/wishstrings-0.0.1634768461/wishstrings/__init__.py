
import os
import types
import gettext

CUR_DIR = os.path.abspath(os.path.dirname(__file__))
LOCALE_DIR = os.path.join(CUR_DIR, "locale")

"""

    The following two functions are monkey patched into the translator
    objects returned from gettext.translation to avoid a weird bug.

    If you have i18n("Wish") and ni18n(num, "Wish", "Wishes"), tools will
    merge the strings into the following PoFile definition:

    msgid "Wish"
    msgid_plural "Wishes"
    msgstr[0] ""
    msgstr[1] ""

    This is fine, except that the following functions in the gettext
    package will only look up strings via direct id lookup, so the singular
    string will never find a translation

    To circumvent this, I copied these functions from the package and
    modified them to fallback to a hardcoded singular lookup if the simple
    key lookup fails.

"""

def gettext_monkeypatch(self, message):
    missing = object()
    tmsg = self._catalog.get(message, missing)
    if tmsg is missing:
        try:
            tmsg = self._catalog[(message, self.plural(1))]
        except KeyError:
            tmsg = missing
    if tmsg is missing:
        if self._fallback:
            return self._fallback.gettext(message)
        return message
    # Encode the Unicode tmsg back to an 8-bit string, if possible
    if self._output_charset:
        return tmsg.encode(self._output_charset)
    elif self._charset:
        return tmsg.encode(self._charset)
    return tmsg


def ugettext_monkeypatch(self, message):
    missing = object()
    tmsg = self._catalog.get(message, missing)
    if tmsg is missing:
        try:
            tmsg = self._catalog[(message, self.plural(1))]
        except KeyError:
            tmsg = missing
    if tmsg is missing:
        if self._fallback:
            return self._fallback.ugettext(message)
        return unicode(message)
    return tmsg

def get_available_locales():
		try:
				return [locale for locale in os.listdir(LOCALE_DIR)]
		except:
				return []

def get_translator_for_locale(locale):
    translator = gettext.translation(
        "wish",
        LOCALE_DIR,
        languages = [locale],
        fallback = True,
        codeset = "UTF-8",
    )
    if isinstance(translator, gettext.GNUTranslations):
        translator.gettext = types.MethodType(gettext_monkeypatch, translator)
        translator.ugettext = types.MethodType(ugettext_monkeypatch, translator)
    return translator

__all__ = [
	  'get_available_locales',
    'get_translator_for_locale',
]
