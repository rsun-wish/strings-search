
from setuptools import setup, find_packages

setup(name = 'wishstrings',
    version = '0.0.1634768461',
    description = "Translated strings for wish",
    packages = find_packages(),
    include_package_data = True,
    zip_safe = False)